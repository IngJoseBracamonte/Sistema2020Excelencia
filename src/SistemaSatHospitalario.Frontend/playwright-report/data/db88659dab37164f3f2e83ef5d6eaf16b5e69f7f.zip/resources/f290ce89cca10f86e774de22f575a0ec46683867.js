var e={production:!0,apiUrl:"",systemVersion:"1.2.83"};export{e as a};
